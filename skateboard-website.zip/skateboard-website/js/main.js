// 移动端导航
document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');

    if (hamburger) {
        hamburger.addEventListener('click', () => {
            navMenu.classList.toggle('active');
        });
    }

    document.querySelectorAll('.nav-menu a').forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
        });
    });

    // 滚动显示动画
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

    document.querySelectorAll('.course-card, .team-card, .gallery-item, .stat-item').forEach((el, i) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = `all 0.6s ease ${i * 0.08}s`;
        observer.observe(el);
    });

    // 数字滚动
    const nums = document.querySelectorAll('.stat-item h3');
    const numObs = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = entry.target;
                const final = parseInt(target.textContent);
                const suffix = target.textContent.replace(/[0-9]/g, '');
                animateNumber(target, 0, final, 2000, suffix);
                numObs.unobserve(target);
            }
        });
    }, { threshold: 0.5 });

    nums.forEach(n => numObs.observe(n));
});

function animateNumber(el, start, end, dur, suffix = '') {
    let st = null;
    function step(ts) {
        if (!st) st = ts;
        const p = Math.min((ts - st) / dur, 1);
        const ease = 1 - Math.pow(1 - p, 4);
        el.textContent = Math.floor(ease * (end - start) + start) + suffix;
        if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
}

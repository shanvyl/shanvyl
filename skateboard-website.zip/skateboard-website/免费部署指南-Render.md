# 🚀 24h滑板公园 - Render 免费部署指南

Render 是一个支持免费部署 Node.js 应用的平台，提供：
- ✅ 免费 HTTPS 域名
- ✅ 持久化磁盘存储（数据不会丢失）
- ✅ 自动部署（Git推送后自动更新）
- ✅ 无需信用卡

---

## 📋 部署前准备

1. **GitHub 账号**（用于代码托管）
2. **Render 账号**（使用 GitHub 登录即可）

---

## 第一步：上传代码到 GitHub

### 1. 创建 GitHub 仓库
1. 访问 https://github.com/new
2. 仓库名称：`24h-skatepark`（或任意名称）
3. 选择 **Public**（公开）
4. 点击 **Create repository**

### 2. 上传本地代码
在项目根目录（skateboard-website文件夹）执行：

```bash
# 初始化 Git 仓库
git init

# 添加所有文件
git add .

# 提交代码
git commit -m "Initial commit"

# 连接远程仓库（把下面的用户名改成你的GitHub用户名）
git remote add origin https://github.com/你的用户名/24h-skatepark.git

# 推送代码
git branch -M main
git push -u origin main
```

> 💡 如果不会用命令行，可以用 GitHub Desktop 客户端：https://desktop.github.com

---

## 第二步：部署后端服务

### 1. 登录 Render
1. 访问 https://dashboard.render.com
2. 点击 **Sign in with GitHub** 用 GitHub 账号登录

### 2. 创建 Web Service
1. 点击 **New +** → **Web Service**
2. 选择你刚创建的 GitHub 仓库 `24h-skatepark`
3. 点击 **Connect**

### 3. 配置服务
填写以下信息：

| 配置项 | 填写内容 |
|--------|----------|
| **Name** | `skateboard-api` |
| **Region** | `Singapore`（新加坡，离中国最近）|
| **Branch** | `main` |
| **Runtime** | `Node` |
| **Build Command** | `cd admin && npm install` |
| **Start Command** | `cd admin && node server.js` |
| **Plan** | `Free` |

### 4. 添加环境变量
点击 **Advanced** → **Add Environment Variable**：

| Key | Value |
|-----|-------|
| `NODE_ENV` | `production` |
| `SESSION_SECRET` | `your-random-secret-key-2026`（随机字符串）|

### 5. 添加磁盘（重要！）
点击 **Add Disk**：

| 配置 | 值 |
|------|-----|
| **Name** | `data` |
| **Mount Path** | `/opt/render/project/src/admin/database` |
| **Size** | `1 GB` |

再添加一个磁盘用于上传文件：

| 配置 | 值 |
|------|-----|
| **Name** | `uploads` |
| **Mount Path** | `/opt/render/project/src/admin/static/uploads` |
| **Size** | `1 GB` |

> ⚠️ **磁盘是必须的！** 否则数据会在实例重启后丢失

### 6. 创建服务
点击 **Create Web Service**

等待部署完成（约3-5分钟），你会得到一个类似这样的地址：
```
https://skateboard-api.onrender.com
```

---

## 第三步：部署前端网站

### 1. 创建 Static Site
1. 点击 **New +** → **Static Site**
2. 选择同一个 GitHub 仓库
3. 点击 **Connect**

### 2. 配置静态网站
| 配置项 | 填写内容 |
|--------|----------|
| **Name** | `skateboard-website` |
| **Branch** | `main` |
| **Build Command** | 留空（不填）|
| **Publish Directory** | `.`（根目录）|

### 3. 创建网站
点击 **Create Static Site**

等待部署完成，你会得到前端地址：
```
https://skateboard-website.onrender.com
```

---

## 第四步：配置前端 API 地址

现在需要修改前端页面，让它们连接到后端 API。

### 修改 contact.html

找到约第 200 行的 JavaScript 代码，修改 API 地址：

```javascript
// 原来的（本地开发）
// const API_BASE = 'http://localhost:5000';

// 修改为（Render部署后）
const API_BASE = 'https://skateboard-api.onrender.com';
```

### 修改 payment.html

同样修改 API 地址为你的后端地址。

### 提交修改

```bash
git add .
git commit -m "Update API base URL for production"
git push
```

---

## 第五步：访问网站

| 地址 | 用途 |
|------|------|
| `https://skateboard-website.onrender.com` | 前台网站 |
| `https://skateboard-api.onrender.com/admin/login.html` | 后台登录 |

### 默认账号
- 账号：`admin`
- 密码：`admin123`

---

## ⚠️ 免费版限制

| 限制 | 说明 |
|------|------|
| **休眠机制** | 15分钟无访问会休眠，下次访问需等待30秒唤醒 |
| **磁盘大小** | 总共2GB（数据+上传文件）|
| **带宽** | 100GB/月（足够正常使用）|
| **构建时间** | 每月500分钟 |

### 保持服务唤醒（可选）
使用 UptimeRobot 定时访问，防止休眠：
1. 访问 https://uptimerobot.com
2. 注册并添加监控
3. 输入你的 API 地址：`https://skateboard-api.onrender.com/health`
4. 设置每5分钟检查一次

---

## 🔄 后续更新

代码修改后推送 GitHub，Render 会自动重新部署：

```bash
git add .
git commit -m "你的修改说明"
git push
```

---

## 🐛 常见问题

### Q: 部署失败怎么办？
点击服务页面的 **Logs** 查看错误信息，常见问题：
- Build Command 填错
- 缺少 package.json
- 代码语法错误

### Q: 图片上传失败？
检查磁盘是否正确挂载到 `/opt/render/project/src/admin/static/uploads`

### Q: 数据丢失了？
免费版实例会休眠，但配置了磁盘后数据不会丢失。如果没有配置磁盘，每次重启数据都会重置。

### Q: 访问很慢？
Render 免费版服务器在美国，可以：
1. 使用 CDN 加速（Cloudflare）
2. 升级到付费版（$7/月，有新加坡节点）

### Q: 想用自己的域名？
1. 在 Render 服务页面点击 **Settings** → **Custom Domains**
2. 添加你的域名
3. 在域名服务商处添加 CNAME 记录指向 Render

---

## 📞 需要帮助？

- Render 文档：https://render.com/docs
- 问题反馈：在 GitHub Issues 提问

**祝部署顺利！🎉**

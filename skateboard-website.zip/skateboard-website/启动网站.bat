@echo off
chcp 65001 >nul
title 24h滑板公园网站
echo ==========================================
echo 🛹 24h滑板公园 - 本地启动工具
echo ==========================================
echo.

:: 检查是否在 admin 目录的父目录
echo [1/3] 检查项目结构...
if exist "admin\package.json" (
    echo    ✓ 找到后端服务
) else (
    echo    ✗ 未找到后端服务，请确保在 skateboard-website 目录运行
    pause
    exit /b 1
)

:: 检查 Node.js
echo [2/3] 检查 Node.js 环境...
node --version >nul 2>&1
if errorlevel 1 (
    echo    ✗ 未检测到 Node.js
    echo    请访问 https://nodejs.org 下载安装 LTS 版本
    start https://nodejs.org/
    pause
    exit /b 1
)
echo    ✓ Node.js 已安装

:: 安装依赖（首次）
echo [3/3] 检查依赖...
cd admin
if not exist "node_modules" (
    echo    首次启动，正在安装依赖...
    call npm install
    if errorlevel 1 (
        echo    ✗ 依赖安装失败
        pause
        exit /b 1
    )
)
echo    ✓ 依赖已就绪

echo.
echo ==========================================
echo 启动选项：
echo ==========================================
echo.
echo [1] 启动后台服务（管理后台）
echo [2] 用浏览器打开前台网站
echo [3] 同时启动服务和打开网站
echo.
set /p choice=请输入数字 (1-3): 

if "%choice%"=="1" goto start_server
if "%choice%"=="2" goto open_website
if "%choice%"=="3" goto start_all
goto end

:start_server
echo.
echo ==========================================
echo 正在启动后台服务...
echo ==========================================
echo.
echo 访问地址：
echo   - 前台网站: http://localhost:5000
echo   - 后台管理: http://localhost:5000/admin.html
echo   - 默认账号: admin / admin123
echo.
echo 按 Ctrl+C 停止服务
echo.
npm start
goto end

:open_website
echo.
echo 正在打开前台网站...
start http://localhost:5000
goto end

:start_all
echo.
echo 正在启动后台服务并打开网站...
start cmd /k "cd /d %~dp0admin && npm start"
timeout /t 3 >nul
start http://localhost:5000
echo.
echo ==========================================
echo 服务已启动！
echo ==========================================
echo.
echo 访问地址：
echo   - 前台网站: http://localhost:5000
echo   - 后台管理: http://localhost:5000/admin.html
echo   - 默认账号: admin / admin123
echo.

:end
echo.
pause

@echo off
chcp 65001 >nul
title 部署到 Render - 24h滑板公园
echo ==========================================
echo 🚀 24h滑板公园 - Render 部署助手
echo ==========================================
echo.

REM 检查 Git 是否安装
git --version >nul 2>&1
if errorlevel 1 (
    echo [❌ 错误] 未检测到 Git，请先安装 Git
    echo 下载地址: https://git-scm.com/download/win
    pause
    exit /b 1
)

echo [✅] Git 已安装
echo.

REM 检查是否已初始化 Git
if not exist ".git" (
    echo [步骤 1/4] 初始化 Git 仓库...
    git init
    git add .
    git commit -m "Initial commit"
    echo [✅] Git 仓库初始化完成
) else (
    echo [✅] Git 仓库已存在
)
echo.

REM 检查是否已连接远程仓库
git remote -v >nul 2>&1
if errorlevel 1 (
    echo [步骤 2/4] 连接 GitHub 远程仓库...
    echo.
    echo 请先完成以下步骤：
    echo 1. 访问 https://github.com/new 创建新仓库
    echo 2. 仓库名称建议：24h-skatepark
    echo 3. 选择 Public（公开仓库）
    echo 4. 不要勾选 README 和 .gitignore
    echo.
    set /p REPO_URL="请输入你的仓库地址（例如：https://github.com/用户名/仓库名.git）: "
    
    git remote add origin %REPO_URL%
    git branch -M main
    git push -u origin main
    
    if errorlevel 1 (
        echo [❌] 推送失败，请检查仓库地址是否正确
        pause
        exit /b 1
    )
    echo [✅] 代码已推送到 GitHub
) else (
    echo [步骤 2/4] 更新代码到 GitHub...
    git add .
    git commit -m "Update for Render deployment"
    git push
    echo [✅] 代码已更新到 GitHub
)
echo.

echo ==========================================
echo [步骤 3/4] 部署配置检查
echo ==========================================
echo.

REM 检查关键文件
if not exist "admin\package.json" (
    echo [❌] 缺少 admin/package.json 文件
    pause
    exit /b 1
)

if not exist "admin\server.js" (
    echo [❌] 缺少 admin/server.js 文件
    pause
    exit /b 1
)

echo [✅] 必要文件检查通过
echo.

echo ==========================================
echo [步骤 4/4] 部署指南
echo ==========================================
echo.
echo 接下来请完成以下步骤：
echo.
echo ┌─────────────────────────────────────────┐
echo │  1. 访问 https://dashboard.render.com   │
echo │     用 GitHub 账号登录                   │
echo │                                          │
echo │  2. 点击 "New +" → "Web Service"        │
echo │     选择你的 GitHub 仓库                 │
echo │                                          │
echo │  3. 填写配置：                           │
echo │     - Name: skateboard-api              │
echo │     - Region: Singapore                 │
echo │     - Build: cd admin ^&^& npm install  │
echo │     - Start: cd admin ^&^& node server.js│
echo │     - Plan: Free                        │
echo │                                          │
echo │  4. 点击 "Advanced" 添加 Disk：          │
echo │     - Mount Path:                       │
echo │       /opt/render/project/src/admin/    │
echo │       database                          │
echo │     - Size: 1GB                         │
echo │                                          │
echo │  5. 再添加一个 Disk：                    │
echo │     - Mount Path:                       │
echo │       /opt/render/project/src/admin/    │
echo │       static/uploads                    │
echo │     - Size: 1GB                         │
echo │                                          │
echo │  6. 点击 "Create Web Service"           │
echo └─────────────────────────────────────────┘
echo.
echo 📖 详细教程请查看：免费部署指南-Render.md
echo.
echo 按任意键打开 Render 网站...
pause >nul
start https://dashboard.render.com

echo.
echo ==========================================
echo 🎉 祝部署顺利！
echo ==========================================
pause

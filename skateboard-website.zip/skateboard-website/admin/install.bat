@echo off
chcp 65001 >nul
echo ==========================================
echo 24h滑板公园 - 安装依赖
echo ==========================================
echo.

REM 检查Python是否安装
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到Python，请先安装Python 3.8+
    echo 下载地址: https://www.python.org/downloads/
    pause
    exit /b 1
)

echo 正在安装依赖包...
pip install -r requirements.txt

if errorlevel 1 (
    echo.
    echo [错误] 安装失败
    pause
    exit /b 1
)

echo.
echo [成功] 依赖安装完成！
echo 现在可以运行 start.bat 启动服务
echo.
pause

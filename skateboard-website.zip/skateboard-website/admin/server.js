/**
 * 24h滑板公园 - 后端管理程序 (Node.js版本)
 * 基于 Express + 文件存储
 */

const express = require('express');
const cors = require('cors');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 5000;

// 信任代理（Render需要）
app.set('trust proxy', 1);

// CORS配置 - 允许所有来源（生产环境建议限制具体域名）
app.use(cors({
    origin: true,
    credentials: true
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('static'));

// Session配置
app.use(session({
    secret: process.env.SESSION_SECRET || 'skateboard_admin_secret_key_2026',
    resave: false,
    saveUninitialized: true,
    cookie: { 
        secure: process.env.NODE_ENV === 'production',
        maxAge: 24 * 60 * 60 * 1000 // 24小时
    }
}));

// 静态文件
app.use(express.static('.'));

// 数据存储目录
const DATA_DIR = path.join(__dirname, 'database');
const UPLOAD_DIR = path.join(__dirname, 'static', 'uploads');

// 确保目录存在
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// 数据文件路径
const DB_FILES = {
    admins: path.join(DATA_DIR, 'admins.json'),
    courses: path.join(DATA_DIR, 'courses.json'),
    registrations: path.join(DATA_DIR, 'registrations.json'),
    gallery: path.join(DATA_DIR, 'gallery.json'),
    coaches: path.join(DATA_DIR, 'coaches.json'),
    settings: path.join(DATA_DIR, 'settings.json'),
    orders: path.join(DATA_DIR, 'orders.json')
};

// 文件存储辅助函数
function loadData(file) {
    if (!fs.existsSync(file)) return [];
    try {
        return JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (e) {
        return [];
    }
}

function saveData(file, data) {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// 初始化数据
function initData() {
    // 初始化管理员
    if (!fs.existsSync(DB_FILES.admins) || loadData(DB_FILES.admins).length === 0) {
        const defaultPassword = bcrypt.hashSync('admin123', 10);
        saveData(DB_FILES.admins, [{
            id: 1,
            username: 'admin',
            password: defaultPassword,
            name: '管理员',
            created_at: new Date().toISOString()
        }]);
        console.log('✅ 创建默认管理员账号: admin / admin123');
    }

    // 初始化课程
    if (!fs.existsSync(DB_FILES.courses) || loadData(DB_FILES.courses).length === 0) {
        const defaultCourses = [
            { id: 1, name: '少儿滑板启蒙班', icon: '👶', description: '针对4-10岁儿童设计，通过趣味游戏培养平衡感与协调性', age_range: '4-10岁', class_size: '6人小班', level: '零基础', price: 1980, duration: '12课时', syllabus: '上下板、推行、转弯、刹车、基础Ollie姿势', gift: '护具套装', is_active: 1, sort_order: 0, created_at: new Date().toISOString() },
            { id: 2, name: '街式滑板进阶班', icon: '🛹', description: 'Ollie、Kickflip、Grind、Slide...系统学习街式技巧', age_range: '10岁+', class_size: '8人小班', level: '进阶', price: 2680, duration: '16课时', syllabus: 'Kickflip、Heelflip、Pop Shove-it、50-50、Boardslide、下台阶', gift: '场地畅玩月卡', is_active: 1, sort_order: 1, created_at: new Date().toISOString() },
            { id: 3, name: '长板Dancing & 漂移', icon: '🌊', description: '优雅的Dancing步伐与刺激的Slide漂移', age_range: '12岁+', class_size: '6人小班', level: '风格流', price: 2280, duration: '12课时', syllabus: '交叉步、津燕、小飞侠、Pivot、 Coleman Slide、速降基础', gift: '长板保养套装', is_active: 1, sort_order: 2, created_at: new Date().toISOString() },
            { id: 4, name: 'U池 & 碗池腾空班', icon: '🌀', description: '在专业U池与碗池中练习Drop-in、Air、lip trick', age_range: '有基础', class_size: '4人小班', level: '高阶', price: 3280, duration: '16课时', syllabus: 'Drop-in、Pump、Rock to Fakie、Axle Stall、Air、Lip Trick', gift: '专业头盔1个', is_active: 1, sort_order: 3, created_at: new Date().toISOString() },
            { id: 5, name: '赛事集训营', icon: '🏆', description: '面向比赛选手的封闭式集训', age_range: '竞技向', class_size: '私教/小班', level: '职业选手', price: 5880, duration: '集训营', syllabus: '高难度动作拆解、比赛线路编排、体能训练、心理辅导', gift: '定制队服', is_active: 1, sort_order: 4, created_at: new Date().toISOString() },
            { id: 6, name: '亲子滑板体验课', icon: '👨‍👩‍👧', description: '家长与孩子一起学习滑板，增进亲子互动', age_range: '亲子', class_size: '1大1小', level: '体验', price: 199, duration: '单次体验', syllabus: '基础滑行、亲子互动游戏', gift: '饮品2杯', is_active: 1, sort_order: 5, created_at: new Date().toISOString() },
        ];
        saveData(DB_FILES.courses, defaultCourses);
        console.log('✅ 初始化课程数据');
    }

    // 初始化其他空数据
    Object.keys(DB_FILES).forEach(key => {
        if (!fs.existsSync(DB_FILES[key])) {
            saveData(DB_FILES[key], []);
        }
    });
}

// 文件上传配置
const storage = multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (req, file, cb) => {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
        const ext = path.extname(file.originalname);
        cb(null, `${timestamp}_${file.originalname}`);
    }
});

const upload = multer({ 
    storage,
    limits: { fileSize: 16 * 1024 * 1024 }, // 16MB
    fileFilter: (req, file, cb) => {
        const allowed = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
        cb(null, allowed.includes(path.extname(file.originalname).toLowerCase()));
    }
});

// 登录检查中间件
function requireAuth(req, res, next) {
    if (req.session.adminId) {
        next();
    } else {
        if (req.path.startsWith('/api/')) {
            res.status(401).json({ code: 401, msg: '未登录' });
        } else {
            res.redirect('/');
        }
    }
}

// ==================== 页面路由 ====================

// API 登录
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    const admins = loadData(DB_FILES.admins);
    const admin = admins.find(a => a.username === username);
    
    if (admin && bcrypt.compareSync(password, admin.password)) {
        req.session.adminId = admin.id;
        req.session.adminName = admin.name;
        res.json({ code: 0, msg: '登录成功', data: { name: admin.name } });
    } else {
        res.json({ code: 1, msg: '用户名或密码错误' });
    }
});

// API 登出
app.get('/api/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

// 获取当前用户信息
app.get('/api/me', (req, res) => {
    if (req.session.adminId) {
        res.json({ code: 0, data: { name: req.session.adminName } });
    } else {
        res.json({ code: 401, msg: '未登录' });
    }
});

// 登出
app.get('/admin/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/admin/login');
});

// 首页
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// 管理后台页面（需要登录）
app.get('/admin.html', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, 'admin.html'));
});

// 首页重定向
app.get('/', (req, res) => {
    res.redirect('/admin/login');
});

// ==================== API 路由 ====================

// 课程 API
app.get('/api/courses', (req, res) => {
    const courses = loadData(DB_FILES.courses).sort((a, b) => a.sort_order - b.sort_order);
    res.json({ code: 0, data: courses });
});

app.post('/api/courses', requireAuth, (req, res) => {
    const courses = loadData(DB_FILES.courses);
    const newCourse = {
        id: Date.now(),
        ...req.body,
        created_at: new Date().toISOString()
    };
    courses.push(newCourse);
    saveData(DB_FILES.courses, courses);
    res.json({ code: 0, msg: '创建成功' });
});

app.put('/api/courses/:id', requireAuth, (req, res) => {
    const courses = loadData(DB_FILES.courses);
    const index = courses.findIndex(c => c.id == req.params.id);
    if (index !== -1) {
        courses[index] = { ...courses[index], ...req.body };
        saveData(DB_FILES.courses, courses);
        res.json({ code: 0, msg: '更新成功' });
    } else {
        res.json({ code: 1, msg: '课程不存在' });
    }
});

app.delete('/api/courses/:id', requireAuth, (req, res) => {
    let courses = loadData(DB_FILES.courses);
    courses = courses.filter(c => c.id != req.params.id);
    saveData(DB_FILES.courses, courses);
    res.json({ code: 0, msg: '删除成功' });
});

// 报名 API
app.get('/api/registrations', (req, res) => {
    let regs = loadData(DB_FILES.registrations);
    const { status, page = 1, page_size = 20 } = req.query;
    
    if (status) {
        regs = regs.filter(r => r.status === status);
    }
    
    // 关联课程名称
    const courses = loadData(DB_FILES.courses);
    regs = regs.map(r => ({
        ...r,
        course_name: courses.find(c => c.id == r.course_id)?.name || '-'
    })).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    
    const total = regs.length;
    const start = (page - 1) * page_size;
    const data = regs.slice(start, start + parseInt(page_size));
    
    res.json({ code: 0, data, total });
});

app.post('/api/registrations', (req, res) => {
    const regs = loadData(DB_FILES.registrations);
    const newReg = {
        id: Date.now(),
        ...req.body,
        status: 'pending',
        created_at: new Date().toISOString()
    };
    regs.push(newReg);
    saveData(DB_FILES.registrations, regs);
    res.json({ code: 0, msg: '报名成功，我们会尽快联系您！' });
});

app.put('/api/registrations/:id', requireAuth, (req, res) => {
    const regs = loadData(DB_FILES.registrations);
    const index = regs.findIndex(r => r.id == req.params.id);
    if (index !== -1) {
        regs[index] = { ...regs[index], ...req.body };
        saveData(DB_FILES.registrations, regs);
        res.json({ code: 0, msg: '更新成功' });
    } else {
        res.json({ code: 1, msg: '记录不存在' });
    }
});

app.delete('/api/registrations/:id', requireAuth, (req, res) => {
    let regs = loadData(DB_FILES.registrations);
    regs = regs.filter(r => r.id != req.params.id);
    saveData(DB_FILES.registrations, regs);
    res.json({ code: 0, msg: '删除成功' });
});

// 图库 API
app.get('/api/gallery', (req, res) => {
    let gallery = loadData(DB_FILES.gallery);
    const { category } = req.query;
    
    if (category) {
        gallery = gallery.filter(g => g.category === category && g.is_active);
    }
    
    gallery = gallery.sort((a, b) => a.sort_order - b.sort_order);
    res.json({ code: 0, data: gallery });
});

app.post('/api/gallery', requireAuth, (req, res) => {
    const gallery = loadData(DB_FILES.gallery);
    const newItem = {
        id: Date.now(),
        ...req.body,
        created_at: new Date().toISOString()
    };
    gallery.push(newItem);
    saveData(DB_FILES.gallery, gallery);
    res.json({ code: 0, msg: '创建成功' });
});

app.put('/api/gallery/:id', requireAuth, (req, res) => {
    const gallery = loadData(DB_FILES.gallery);
    const index = gallery.findIndex(g => g.id == req.params.id);
    if (index !== -1) {
        gallery[index] = { ...gallery[index], ...req.body };
        saveData(DB_FILES.gallery, gallery);
        res.json({ code: 0, msg: '更新成功' });
    } else {
        res.json({ code: 1, msg: '记录不存在' });
    }
});

app.delete('/api/gallery/:id', requireAuth, (req, res) => {
    let gallery = loadData(DB_FILES.gallery);
    gallery = gallery.filter(g => g.id != req.params.id);
    saveData(DB_FILES.gallery, gallery);
    res.json({ code: 0, msg: '删除成功' });
});

// 上传 API
app.post('/api/upload', requireAuth, upload.single('file'), (req, res) => {
    if (req.file) {
        res.json({ code: 0, data: { url: `/uploads/${req.file.filename}` } });
    } else {
        res.json({ code: 1, msg: '上传失败' });
    }
});

// 教练 API
app.get('/api/coaches', (req, res) => {
    const coaches = loadData(DB_FILES.coaches).filter(c => c.is_active).sort((a, b) => a.sort_order - b.sort_order);
    res.json({ code: 0, data: coaches });
});

app.post('/api/coaches', requireAuth, (req, res) => {
    const coaches = loadData(DB_FILES.coaches);
    const newCoach = {
        id: Date.now(),
        ...req.body,
        created_at: new Date().toISOString()
    };
    coaches.push(newCoach);
    saveData(DB_FILES.coaches, coaches);
    res.json({ code: 0, msg: '创建成功' });
});

app.put('/api/coaches/:id', requireAuth, (req, res) => {
    const coaches = loadData(DB_FILES.coaches);
    const index = coaches.findIndex(c => c.id == req.params.id);
    if (index !== -1) {
        coaches[index] = { ...coaches[index], ...req.body };
        saveData(DB_FILES.coaches, coaches);
        res.json({ code: 0, msg: '更新成功' });
    } else {
        res.json({ code: 1, msg: '教练不存在' });
    }
});

app.delete('/api/coaches/:id', requireAuth, (req, res) => {
    let coaches = loadData(DB_FILES.coaches);
    coaches = coaches.filter(c => c.id != req.params.id);
    saveData(DB_FILES.coaches, coaches);
    res.json({ code: 0, msg: '删除成功' });
});

// 设置 API
app.get('/api/settings', (req, res) => {
    const settings = loadData(DB_FILES.settings);
    const settingsObj = settings.reduce((acc, s) => ({ ...acc, [s.key]: s.value }), {});
    res.json({ code: 0, data: settingsObj });
});

app.post('/api/settings', requireAuth, (req, res) => {
    let settings = loadData(DB_FILES.settings);
    
    Object.entries(req.body).forEach(([key, value]) => {
        const index = settings.findIndex(s => s.key === key);
        if (index !== -1) {
            settings[index].value = value;
            settings[index].updated_at = new Date().toISOString();
        } else {
            settings.push({ key, value, updated_at: new Date().toISOString() });
        }
    });
    
    saveData(DB_FILES.settings, settings);
    res.json({ code: 0, msg: '保存成功' });
});

// 统计 API
app.get('/api/statistics', (req, res) => {
    const courses = loadData(DB_FILES.courses).filter(c => c.is_active).length;
    const registrations = loadData(DB_FILES.registrations);
    const pending = registrations.filter(r => r.status === 'pending').length;
    const gallery = loadData(DB_FILES.gallery).filter(g => g.is_active).length;
    
    // 近7天趋势
    const trend = [];
    for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        const count = registrations.filter(r => r.created_at && r.created_at.startsWith(dateStr)).length;
        trend.push({ date: dateStr, count });
    }
    
    res.json({ code: 0, data: { course_count: courses, registration_count: registrations.length, pending_count: pending, gallery_count: gallery, trend } });
});

// ==================== 订单 & 支付 API ====================

// 创建订单
app.post('/api/orders', (req, res) => {
    const orders = loadData(DB_FILES.orders);
    const { course_id, name, phone, age_range, message, payment_method } = req.body;
    
    // 获取课程信息
    const courses = loadData(DB_FILES.courses);
    const course = courses.find(c => c.id == course_id);
    
    if (!course) {
        return res.json({ code: 1, msg: '课程不存在' });
    }
    
    // 生成订单号
    const orderNo = 'SK' + Date.now() + Math.floor(Math.random() * 1000);
    
    const newOrder = {
        id: Date.now(),
        order_no: orderNo,
        course_id,
        course_name: course.name,
        course_price: course.price,
        name,
        phone,
        age_range,
        message,
        payment_method, // wechat 或 alipay
        status: 'pending', // pending, paid, cancelled
        pay_time: null,
        created_at: new Date().toISOString()
    };
    
    orders.push(newOrder);
    saveData(DB_FILES.orders, orders);
    
    res.json({ code: 0, msg: '订单创建成功', data: { order_id: newOrder.id, order_no: orderNo } });
});

// 获取订单列表
app.get('/api/orders', requireAuth, (req, res) => {
    let orders = loadData(DB_FILES.orders);
    const { status, page = 1, page_size = 20 } = req.query;
    
    if (status) {
        orders = orders.filter(o => o.status === status);
    }
    
    orders = orders.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    
    const total = orders.length;
    const start = (page - 1) * page_size;
    const data = orders.slice(start, start + parseInt(page_size));
    
    res.json({ code: 0, data, total });
});

// 获取单个订单
app.get('/api/orders/:id', (req, res) => {
    const orders = loadData(DB_FILES.orders);
    const order = orders.find(o => o.id == req.params.id);
    
    if (order) {
        res.json({ code: 0, data: order });
    } else {
        res.json({ code: 1, msg: '订单不存在' });
    }
});

// 模拟支付
app.post('/api/orders/:id/pay', (req, res) => {
    const orders = loadData(DB_FILES.orders);
    const index = orders.findIndex(o => o.id == req.params.id);
    
    if (index === -1) {
        return res.json({ code: 1, msg: '订单不存在' });
    }
    
    const order = orders[index];
    
    if (order.status === 'paid') {
        return res.json({ code: 1, msg: '订单已支付' });
    }
    
    // 模拟支付处理
    orders[index].status = 'paid';
    orders[index].pay_time = new Date().toISOString();
    saveData(DB_FILES.orders, orders);
    
    res.json({ code: 0, msg: '支付成功', data: orders[index] });
});

// 取消订单
app.put('/api/orders/:id/cancel', requireAuth, (req, res) => {
    const orders = loadData(DB_FILES.orders);
    const index = orders.findIndex(o => o.id == req.params.id);
    
    if (index === -1) {
        return res.json({ code: 1, msg: '订单不存在' });
    }
    
    orders[index].status = 'cancelled';
    saveData(DB_FILES.orders, orders);
    
    res.json({ code: 0, msg: '订单已取消' });
});

// 删除订单
app.delete('/api/orders/:id', requireAuth, (req, res) => {
    let orders = loadData(DB_FILES.orders);
    orders = orders.filter(o => o.id != req.params.id);
    saveData(DB_FILES.orders, orders);
    res.json({ code: 0, msg: '删除成功' });
});

// 获取订单统计（用于后台仪表盘）
app.get('/api/order-statistics', requireAuth, (req, res) => {
    const orders = loadData(DB_FILES.orders);
    const total = orders.length;
    const paid = orders.filter(o => o.status === 'paid').length;
    const pending = orders.filter(o => o.status === 'pending').length;
    const cancelled = orders.filter(o => o.status === 'cancelled').length;
    const totalAmount = orders.filter(o => o.status === 'paid').reduce((sum, o) => sum + (parseInt(o.course_price) || 0), 0);
    
    res.json({
        code: 0,
        data: { total, paid, pending, cancelled, total_amount: totalAmount }
    });
});

// 启动服务
initData();
app.listen(PORT, () => {
    console.log('\n========================================');
    console.log('🛹 24h滑板公园 - 管理后台已启动');
    console.log('========================================');
    console.log(`📍 访问地址: http://localhost:${PORT}`);
    console.log(`🔐 登录地址: http://localhost:${PORT}/admin/login`);
    console.log('👤 默认账号: admin / admin123');
    console.log('========================================\n');
});

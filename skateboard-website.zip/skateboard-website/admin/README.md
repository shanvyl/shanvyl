# 24h滑板公园 - 管理后台

基于 Flask + SQLite 的滑板培训机构管理系统。

## 功能特性

- 📚 **课程管理** - 添加、编辑、删除课程信息
- 📝 **报名管理** - 查看和处理学员报名信息
- 🖼️ **图库管理** - 上传和管理学员风采图片
- 👨‍🏫 **教练管理** - 管理教练团队信息
- ⚙️ **系统设置** - 网站基本信息配置

## 安装部署

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 启动服务

```bash
python app.py
```

服务将在 http://localhost:5000 启动

### 3. 访问管理后台

打开浏览器访问：http://localhost:5000/admin/login

默认账号：
- 用户名：admin
- 密码：admin123

## 目录结构

```
admin/
├── app.py              # 主程序
├── requirements.txt    # Python依赖
├── README.md           # 说明文档
├── database/           # 数据库目录
│   └── skateboard.db   # SQLite数据库
├── static/             # 静态文件
│   ├── css/            # 样式文件
│   ├── js/             # 脚本文件
│   └── uploads/        # 上传的图片
└── templates/          # HTML模板
    ├── base.html       # 基础模板
    ├── login.html      # 登录页面
    ├── dashboard.html  # 仪表盘
    ├── courses.html    # 课程管理
    ├── registrations.html # 报名管理
    ├── gallery.html    # 图库管理
    ├── coaches.html    # 教练管理
    └── settings.html   # 系统设置
```

## API 接口

### 课程相关
- `GET /api/courses` - 获取课程列表
- `POST /api/courses` - 创建课程
- `PUT /api/courses/<id>` - 更新课程
- `DELETE /api/courses/<id>` - 删除课程

### 报名相关
- `GET /api/registrations` - 获取报名列表
- `POST /api/registrations` - 提交报名（前台）
- `PUT /api/registrations/<id>` - 更新报名状态
- `DELETE /api/registrations/<id>` - 删除报名

### 图库相关
- `GET /api/gallery` - 获取图库列表
- `POST /api/gallery` - 创建图库项目
- `PUT /api/gallery/<id>` - 更新图库项目
- `DELETE /api/gallery/<id>` - 删除图库项目

### 教练相关
- `GET /api/coaches` - 获取教练列表
- `POST /api/coaches` - 创建教练
- `PUT /api/coaches/<id>` - 更新教练
- `DELETE /api/coaches/<id>` - 删除教练

### 其他
- `POST /api/upload` - 文件上传
- `GET /api/settings` - 获取系统设置
- `POST /api/settings` - 更新系统设置
- `GET /api/statistics` - 获取统计数据

## 技术栈

- **后端**: Flask (Python)
- **数据库**: SQLite
- **前端**: Bootstrap 5 + Vanilla JavaScript
- **样式**: 自定义暗色主题

## 注意事项

1. 首次启动会自动初始化数据库并创建默认管理员账号
2. 上传的文件保存在 `static/uploads/` 目录
3. 数据库文件保存在 `database/skateboard.db`
4. 生产环境部署时请修改 `app.secret_key`

## 开发计划

- [ ] 数据统计图表
- [ ] 管理员权限管理
- [ ] 数据导入导出
- [ ] 日志记录
- [ ] 邮件通知

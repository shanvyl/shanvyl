"""
24h滑板公园 - 后端管理程序
基于 Flask + SQLite
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash
from flask_cors import CORS
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
import sqlite3
import json

app = Flask(__name__)
app.secret_key = 'skateboard_admin_secret_key_2026'
CORS(app)

# 配置
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB

# 确保上传目录存在
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# 数据库路径
DB_PATH = 'database/skateboard.db'
os.makedirs('database', exist_ok=True)


def get_db():
    """获取数据库连接"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """初始化数据库"""
    conn = get_db()
    cursor = conn.cursor()
    
    # 管理员表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 课程表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            icon TEXT,
            description TEXT,
            age_range TEXT,
            class_size TEXT,
            level TEXT,
            price INTEGER,
            duration TEXT,
            syllabus TEXT,
            gift TEXT,
            is_active INTEGER DEFAULT 1,
            sort_order INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 报名表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            age_range TEXT,
            course_id INTEGER,
            message TEXT,
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (course_id) REFERENCES courses (id)
        )
    ''')
    
    # 图片表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS gallery (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            description TEXT,
            image_url TEXT NOT NULL,
            category TEXT,
            is_active INTEGER DEFAULT 1,
            sort_order INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 教练表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS coaches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            title TEXT,
            description TEXT,
            avatar TEXT,
            specialty TEXT,
            is_active INTEGER DEFAULT 1,
            sort_order INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 系统设置表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT UNIQUE NOT NULL,
            value TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 插入默认管理员账号 (admin/admin123)
    default_password = generate_password_hash('admin123')
    cursor.execute('''
        INSERT OR IGNORE INTO admins (username, password, name) 
        VALUES (?, ?, ?)
    ''', ('admin', default_password, '管理员'))
    
    # 插入默认课程数据
    default_courses = [
        ('少儿滑板启蒙班', '👶', '针对4-10岁儿童设计，通过趣味游戏培养平衡感与协调性', '4-10岁', '6人小班', '零基础', 1980, '12课时', '上下板、推行、转弯、刹车、基础Ollie姿势', '护具套装'),
        ('街式滑板进阶班', '🛹', 'Ollie、Kickflip、Grind、Slide...系统学习街式技巧', '10岁+', '8人小班', '进阶', 2680, '16课时', 'Kickflip、Heelflip、Pop Shove-it、50-50、Boardslide、下台阶', '场地畅玩月卡'),
        ('长板Dancing & 漂移', '🌊', '优雅的Dancing步伐与刺激的Slide漂移', '12岁+', '6人小班', '风格流', 2280, '12课时', '交叉步、津燕、小飞侠、Pivot、 Coleman Slide、速降基础', '长板保养套装'),
        ('U池 & 碗池腾空班', '🌀', '在专业U池与碗池中练习Drop-in、Air、lip trick', '有基础', '4人小班', '高阶', 3280, '16课时', 'Drop-in、Pump、Rock to Fakie、Axle Stall、Air、Lip Trick', '专业头盔1个'),
        ('赛事集训营', '🏆', '面向比赛选手的封闭式集训', '竞技向', '私教/小班', '职业选手', 5880, '集训营', '高难度动作拆解、比赛线路编排、体能训练、心理辅导', '定制队服'),
        ('亲子滑板体验课', '👨‍👩‍👧', '家长与孩子一起学习滑板，增进亲子互动', '亲子', '1大1小', '体验', 199, '单次体验', '基础滑行、亲子互动游戏', '饮品2杯'),
    ]
    
    for i, course in enumerate(default_courses):
        cursor.execute('''
            INSERT OR IGNORE INTO courses (name, icon, description, age_range, class_size, level, price, duration, syllabus, gift, sort_order)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (*course, i))
    
    conn.commit()
    conn.close()
    print("数据库初始化完成")


def allowed_file(filename):
    """检查文件扩展名是否允许"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# ==================== 登录相关 ====================

@app.route('/admin/login', methods=['GET', 'POST'])
def login():
    """登录页面"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM admins WHERE username = ?', (username,))
        admin = cursor.fetchone()
        conn.close()
        
        if admin and check_password_hash(admin['password'], password):
            session['admin_id'] = admin['id']
            session['admin_name'] = admin['name']
            return redirect('/admin/dashboard')
        else:
            flash('用户名或密码错误', 'error')
    
    return render_template('login.html')


@app.route('/admin/logout')
def logout():
    """退出登录"""
    session.clear()
    return redirect('/admin/login')


# ==================== 管理后台页面 ====================

@app.route('/admin/dashboard')
def dashboard():
    """管理后台首页"""
    if 'admin_id' not in session:
        return redirect('/admin/login')
    
    conn = get_db()
    cursor = conn.cursor()
    
    # 统计数据
    cursor.execute('SELECT COUNT(*) as count FROM courses WHERE is_active = 1')
    course_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM registrations')
    registration_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM registrations WHERE status = "pending"')
    pending_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM gallery WHERE is_active = 1')
    gallery_count = cursor.fetchone()['count']
    
    # 最近报名
    cursor.execute('''
        SELECT r.*, c.name as course_name 
        FROM registrations r 
        LEFT JOIN courses c ON r.course_id = c.id 
        ORDER BY r.created_at DESC 
        LIMIT 5
    ''')
    recent_registrations = cursor.fetchall()
    
    conn.close()
    
    return render_template('dashboard.html', 
                         course_count=course_count,
                         registration_count=registration_count,
                         pending_count=pending_count,
                         gallery_count=gallery_count,
                         recent_registrations=recent_registrations)


@app.route('/admin/courses')
def courses_page():
    """课程管理页面"""
    if 'admin_id' not in session:
        return redirect('/admin/login')
    return render_template('courses.html')


@app.route('/admin/registrations')
def registrations_page():
    """报名管理页面"""
    if 'admin_id' not in session:
        return redirect('/admin/login')
    return render_template('registrations.html')


@app.route('/admin/gallery')
def gallery_page():
    """图库管理页面"""
    if 'admin_id' not in session:
        return redirect('/admin/login')
    return render_template('gallery.html')


@app.route('/admin/coaches')
def coaches_page():
    """教练管理页面"""
    if 'admin_id' not in session:
        return redirect('/admin/login')
    return render_template('coaches.html')


@app.route('/admin/settings')
def settings_page():
    """系统设置页面"""
    if 'admin_id' not in session:
        return redirect('/admin/login')
    return render_template('settings.html')


# ==================== API 接口 ====================

# 课程 API
@app.route('/api/courses', methods=['GET'])
def get_courses():
    """获取课程列表"""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM courses ORDER BY sort_order, id')
    courses = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify({'code': 0, 'data': courses})


@app.route('/api/courses', methods=['POST'])
def create_course():
    """创建课程"""
    if 'admin_id' not in session:
        return jsonify({'code': 401, 'msg': '未登录'})
    
    data = request.json
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO courses (name, icon, description, age_range, class_size, level, price, duration, syllabus, gift, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (data.get('name'), data.get('icon'), data.get('description'), 
          data.get('age_range'), data.get('class_size'), data.get('level'),
          data.get('price'), data.get('duration'), data.get('syllabus'),
          data.get('gift'), data.get('sort_order', 0)))
    conn.commit()
    conn.close()
    return jsonify({'code': 0, 'msg': '创建成功'})


@app.route('/api/courses/<int:course_id>', methods=['PUT'])
def update_course(course_id):
    """更新课程"""
    if 'admin_id' not in session:
        return jsonify({'code': 401, 'msg': '未登录'})
    
    data = request.json
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE courses SET 
            name = ?, icon = ?, description = ?, age_range = ?, 
            class_size = ?, level = ?, price = ?, duration = ?,
            syllabus = ?, gift = ?, sort_order = ?, is_active = ?
        WHERE id = ?
    ''', (data.get('name'), data.get('icon'), data.get('description'),
          data.get('age_range'), data.get('class_size'), data.get('level'),
          data.get('price'), data.get('duration'), data.get('syllabus'),
          data.get('gift'), data.get('sort_order', 0), data.get('is_active', 1),
          course_id))
    conn.commit()
    conn.close()
    return jsonify({'code': 0, 'msg': '更新成功'})


@app.route('/api/courses/<int:course_id>', methods=['DELETE'])
def delete_course(course_id):
    """删除课程"""
    if 'admin_id' not in session:
        return jsonify({'code': 401, 'msg': '未登录'})
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM courses WHERE id = ?', (course_id,))
    conn.commit()
    conn.close()
    return jsonify({'code': 0, 'msg': '删除成功'})


# 报名 API
@app.route('/api/registrations', methods=['GET'])
def get_registrations():
    """获取报名列表"""
    status = request.args.get('status', '')
    page = int(request.args.get('page', 1))
    page_size = int(request.args.get('page_size', 20))
    offset = (page - 1) * page_size
    
    conn = get_db()
    cursor = conn.cursor()
    
    where_clause = ''
    params = []
    if status:
        where_clause = 'WHERE r.status = ?'
        params = [status]
    
    cursor.execute(f'''
        SELECT r.*, c.name as course_name 
        FROM registrations r 
        LEFT JOIN courses c ON r.course_id = c.id 
        {where_clause}
        ORDER BY r.created_at DESC 
        LIMIT ? OFFSET ?
    ''', params + [page_size, offset])
    registrations = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute(f'SELECT COUNT(*) as count FROM registrations r {where_clause}', params)
    total = cursor.fetchone()['count']
    
    conn.close()
    return jsonify({'code': 0, 'data': registrations, 'total': total})


@app.route('/api/registrations', methods=['POST'])
def create_registration():
    """提交报名（前台接口）"""
    data = request.json
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO registrations (name, phone, age_range, course_id, message)
        VALUES (?, ?, ?, ?, ?)
    ''', (data.get('name'), data.get('phone'), data.get('age_range'),
          data.get('course_id'), data.get('message')))
    conn.commit()
    conn.close()
    return jsonify({'code': 0, 'msg': '报名成功，我们会尽快联系您！'})


@app.route('/api/registrations/<int:reg_id>', methods=['PUT'])
def update_registration(reg_id):
    """更新报名状态"""
    if 'admin_id' not in session:
        return jsonify({'code': 401, 'msg': '未登录'})
    
    data = request.json
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE registrations SET status = ? WHERE id = ?',
                   (data.get('status'), reg_id))
    conn.commit()
    conn.close()
    return jsonify({'code': 0, 'msg': '更新成功'})


@app.route('/api/registrations/<int:reg_id>', methods=['DELETE'])
def delete_registration(reg_id):
    """删除报名"""
    if 'admin_id' not in session:
        return jsonify({'code': 401, 'msg': '未登录'})
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM registrations WHERE id = ?', (reg_id,))
    conn.commit()
    conn.close()
    return jsonify({'code': 0, 'msg': '删除成功'})


# 图库 API
@app.route('/api/gallery', methods=['GET'])
def get_gallery():
    """获取图库列表"""
    category = request.args.get('category', '')
    conn = get_db()
    cursor = conn.cursor()
    
    if category:
        cursor.execute('SELECT * FROM gallery WHERE category = ? AND is_active = 1 ORDER BY sort_order, id', (category,))
    else:
        cursor.execute('SELECT * FROM gallery WHERE is_active = 1 ORDER BY sort_order, id')
    
    gallery = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify({'code': 0, 'data': gallery})


@app.route('/api/gallery', methods=['POST'])
def create_gallery():
    """创建图库项目"""
    if 'admin_id' not in session:
        return jsonify({'code': 401, 'msg': '未登录'})
    
    data = request.json
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO gallery (title, description, image_url, category, sort_order)
        VALUES (?, ?, ?, ?, ?)
    ''', (data.get('title'), data.get('description'), data.get('image_url'),
          data.get('category'), data.get('sort_order', 0)))
    conn.commit()
    conn.close()
    return jsonify({'code': 0, 'msg': '创建成功'})


@app.route('/api/gallery/<int:gallery_id>', methods=['PUT'])
def update_gallery(gallery_id):
    """更新图库项目"""
    if 'admin_id' not in session:
        return jsonify({'code': 401, 'msg': '未登录'})
    
    data = request.json
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE gallery SET title = ?, description = ?, image_url = ?, 
        category = ?, sort_order = ?, is_active = ? WHERE id = ?
    ''', (data.get('title'), data.get('description'), data.get('image_url'),
          data.get('category'), data.get('sort_order', 0), data.get('is_active', 1),
          gallery_id))
    conn.commit()
    conn.close()
    return jsonify({'code': 0, 'msg': '更新成功'})


@app.route('/api/gallery/<int:gallery_id>', methods=['DELETE'])
def delete_gallery(gallery_id):
    """删除图库项目"""
    if 'admin_id' not in session:
        return jsonify({'code': 401, 'msg': '未登录'})
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM gallery WHERE id = ?', (gallery_id,))
    conn.commit()
    conn.close()
    return jsonify({'code': 0, 'msg': '删除成功'})


# 文件上传 API
@app.route('/api/upload', methods=['POST'])
def upload_file():
    """上传文件"""
    if 'admin_id' not in session:
        return jsonify({'code': 401, 'msg': '未登录'})
    
    if 'file' not in request.files:
        return jsonify({'code': 1, 'msg': '没有文件'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'code': 1, 'msg': '文件名为空'})
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        # 添加时间戳避免重名
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{timestamp}_{filename}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        return jsonify({'code': 0, 'data': {'url': f'/static/uploads/{filename}'}})
    
    return jsonify({'code': 1, 'msg': '不支持的文件类型'})


# 教练 API
@app.route('/api/coaches', methods=['GET'])
def get_coaches():
    """获取教练列表"""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM coaches WHERE is_active = 1 ORDER BY sort_order, id')
    coaches = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify({'code': 0, 'data': coaches})


@app.route('/api/coaches', methods=['POST'])
def create_coach():
    """创建教练"""
    if 'admin_id' not in session:
        return jsonify({'code': 401, 'msg': '未登录'})
    
    data = request.json
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO coaches (name, title, description, avatar, specialty, sort_order)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (data.get('name'), data.get('title'), data.get('description'),
          data.get('avatar'), data.get('specialty'), data.get('sort_order', 0)))
    conn.commit()
    conn.close()
    return jsonify({'code': 0, 'msg': '创建成功'})


@app.route('/api/coaches/<int:coach_id>', methods=['PUT'])
def update_coach(coach_id):
    """更新教练"""
    if 'admin_id' not in session:
        return jsonify({'code': 401, 'msg': '未登录'})
    
    data = request.json
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE coaches SET name = ?, title = ?, description = ?, 
        avatar = ?, specialty = ?, sort_order = ?, is_active = ? WHERE id = ?
    ''', (data.get('name'), data.get('title'), data.get('description'),
          data.get('avatar'), data.get('specialty'), data.get('sort_order', 0),
          data.get('is_active', 1), coach_id))
    conn.commit()
    conn.close()
    return jsonify({'code': 0, 'msg': '更新成功'})


@app.route('/api/coaches/<int:coach_id>', methods=['DELETE'])
def delete_coach(coach_id):
    """删除教练"""
    if 'admin_id' not in session:
        return jsonify({'code': 401, 'msg': '未登录'})
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM coaches WHERE id = ?', (coach_id,))
    conn.commit()
    conn.close()
    return jsonify({'code': 0, 'msg': '删除成功'})


# 系统设置 API
@app.route('/api/settings', methods=['GET'])
def get_settings():
    """获取系统设置"""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM settings')
    settings = {row['key']: row['value'] for row in cursor.fetchall()}
    conn.close()
    return jsonify({'code': 0, 'data': settings})


@app.route('/api/settings', methods=['POST'])
def update_settings():
    """更新系统设置"""
    if 'admin_id' not in session:
        return jsonify({'code': 401, 'msg': '未登录'})
    
    data = request.json
    conn = get_db()
    cursor = conn.cursor()
    
    for key, value in data.items():
        cursor.execute('''
            INSERT INTO settings (key, value) VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value = ?, updated_at = CURRENT_TIMESTAMP
        ''', (key, value, value))
    
    conn.commit()
    conn.close()
    return jsonify({'code': 0, 'msg': '保存成功'})


# 统计数据 API
@app.route('/api/statistics', methods=['GET'])
def get_statistics():
    """获取统计数据"""
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) as count FROM courses WHERE is_active = 1')
    course_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM registrations')
    registration_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM registrations WHERE status = "pending"')
    pending_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM gallery WHERE is_active = 1')
    gallery_count = cursor.fetchone()['count']
    
    # 近7天报名趋势
    cursor.execute('''
        SELECT DATE(created_at) as date, COUNT(*) as count 
        FROM registrations 
        WHERE created_at >= DATE('now', '-7 days')
        GROUP BY DATE(created_at)
        ORDER BY date
    ''')
    trend = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    return jsonify({
        'code': 0,
        'data': {
            'course_count': course_count,
            'registration_count': registration_count,
            'pending_count': pending_count,
            'gallery_count': gallery_count,
            'trend': trend
        }
    })


# 静态文件服务
@app.route('/static/uploads/<path:filename>')
def uploaded_file(filename):
    return app.send_static_file(f'uploads/{filename}')


# 首页重定向到登录
@app.route('/')
def index():
    return redirect('/admin/login')


if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)

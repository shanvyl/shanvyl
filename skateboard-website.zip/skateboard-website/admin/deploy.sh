#!/bin/bash
# 24h滑板公园 - 一键部署脚本
# 使用方法: chmod +x deploy.sh && ./deploy.sh

echo "========================================"
echo "🚀 24h滑板公园网站部署脚本"
echo "========================================"
echo ""

# 配置变量
PROJECT_NAME="skateboard-website"
PROJECT_DIR="/var/www/$PROJECT_NAME"
BACKEND_DIR="$PROJECT_DIR/admin"
NGINX_CONF="/etc/nginx/sites-available/skateboard"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 检查是否root用户
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}请使用 root 权限运行此脚本${NC}"
    echo "sudo ./deploy.sh"
    exit 1
fi

echo -e "${YELLOW}[1/8] 更新系统...${NC}"
apt update && apt upgrade -y

echo -e "${YELLOW}[2/8] 安装 Node.js...${NC}"
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt-get install -y nodejs
fi
node -v
npm -v

echo -e "${YELLOW}[3/8] 安装 PM2...${NC}"
if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
fi
pm2 --version

echo -e "${YELLOW}[4/8] 安装 Nginx...${NC}"
if ! command -v nginx &> /dev/null; then
    apt install nginx -y
fi

echo -e "${YELLOW}[5/8] 创建项目目录...${NC}"
mkdir -p $PROJECT_DIR
mkdir -p $BACKEND_DIR/static/uploads
mkdir -p $BACKEND_DIR/database

# 复制当前目录文件到项目目录
echo -e "${YELLOW}[6/8] 复制项目文件...${NC}"
cp -r . $BACKEND_DIR/

echo -e "${YELLOW}[7/8] 安装项目依赖...${NC}"
cd $BACKEND_DIR
npm install

echo -e "${YELLOW}[8/8] 启动服务...${NC}"
pm2 delete $PROJECT_NAME 2>/dev/null || true
pm2 start server.js --name $PROJECT_NAME
pm2 save
pm2 startup

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}✅ 部署完成！${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo "项目目录: $BACKEND_DIR"
echo ""
echo "PM2 状态:"
pm2 status
pm2 save

echo ""
echo -e "${YELLOW}下一步操作:${NC}"
echo "1. 配置 Nginx 反向代理"
echo "2. 配置域名解析"
echo "3. 申请 SSL 证书 (HTTPS)"
echo ""
echo "详细配置请参考: 部署指南.md"
echo ""

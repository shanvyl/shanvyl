@echo off
chcp 65001 >nul
echo ==========================================
echo 24h滑板公园 - 管理后台启动脚本
echo ==========================================
echo.

REM 检查Python是否安装
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到Python，请先安装Python 3.8+
    pause
    exit /b 1
)

echo [1/3] 正在检查依赖...
pip show flask >nul 2>&1
if errorlevel 1 (
    echo [2/3] 正在安装依赖...
    pip install -r requirements.txt
) else (
    echo [2/3] 依赖已安装，跳过
)

echo [3/3] 正在启动服务...
echo.
echo ==========================================
echo 管理后台地址: http://localhost:5000
echo 登录地址: http://localhost:5000/admin/login
echo 默认账号: admin / admin123
echo ==========================================
echo 按 Ctrl+C 停止服务
echo.

python app.py

pause

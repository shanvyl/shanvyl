@echo off
chcp 65001 >nul
echo ==========================================
echo 🛹 24h滑板公园 - 管理后台
echo ==========================================
echo.
echo 正在启动服务...
echo.

REM 检查node_modules是否存在
if not exist "node_modules" (
    echo [提示] 首次启动，正在安装依赖...
    call npm install
    if errorlevel 1 (
        echo [错误] 依赖安装失败
        pause
        exit /b 1
    )
)

echo.
echo ==========================================
echo 服务启动后，请访问:
echo http://localhost:5000
echo.
echo 默认账号: admin / admin123
echo ==========================================
echo.
echo 按 Ctrl+C 可以停止服务
echo.

node server.js

pause
